
CREATE TABLE dim_aluno (
  id_aluno INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  nome VARCHAR(255) NULL,
  idade INTEGER UNSIGNED NULL,
  PRIMARY KEY(id_aluno)
);


CREATE TABLE dim_curso (
  id_curso INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  descricao VARCHAR(45) NULL,
  PRIMARY KEY(id_curso)
);



CREATE TABLE dim_disciplina (
  id_disciplina INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  descricao VARCHAR(255) NULL,
  PRIMARY KEY(id_disciplina)
);


CREATE TABLE dim_tempo (
  id_tempo INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  semestre INTEGER UNSIGNED NULL,
  ano INTEGER UNSIGNED NULL,
  PRIMARY KEY(id_tempo)
);



CREATE TABLE fato_aulas (
  idfato_aulas INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  id_curso INTEGER UNSIGNED NOT NULL,
  id_tempo INTEGER UNSIGNED NOT NULL,
  id_aluno INTEGER UNSIGNED NOT NULL,
  id_disciplina INTEGER UNSIGNED NOT NULL,
  quantidade_aprovados INTEGER UNSIGNED NULL,
  quantidade_reprovados INTEGER UNSIGNED NULL,
  quantidade_alunos_curso INTEGER UNSIGNED NULL,
  quantidade_discip_curso INTEGER UNSIGNED NULL,
  PRIMARY KEY(idfato_aulas),
  INDEX fato_aulas_FKIndex1(id_aluno),
  INDEX fato_aulas_FKIndex2(id_tempo),
  INDEX fato_aulas_FKIndex3(id_curso),
  INDEX fato_aulas_FKIndex4(id_disciplina)
);

